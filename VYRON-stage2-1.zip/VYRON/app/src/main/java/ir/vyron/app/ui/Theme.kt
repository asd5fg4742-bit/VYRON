package ir.vyron.app.ui

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF39FF7A)
val Background = Color(0xFF0B0F0D)
val SurfaceColor = Color(0xFF131A16)
val TextColor = Color(0xFFEAF5EE)
val MutedColor = Color(0xFF8FA398)

val VyronColors = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF04140A),
    background = Background,
    onBackground = TextColor,
    surface = SurfaceColor,
    onSurface = TextColor,
    surfaceVariant = Color(0xFF1B241F),
    onSurfaceVariant = MutedColor
)

/** انتخاب متن بر اساس زبان. */
fun tr(lang: String, fa: String, en: String): String = if (lang == "en") en else fa
