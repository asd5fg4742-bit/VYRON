package ir.vyron.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.vyron.app.data.DayState
import ir.vyron.app.data.DayStore
import ir.vyron.app.domain.RewardRules
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun HomeScreen(
    lang: String,
    name: String,
    store: DayStore,
    onEdit: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    val state by store.state.collectAsState(initial = DayState())
    val scope = rememberCoroutineScope()
    val today = LocalDate.now().toString()
    val inSchool = RewardRules.isSchoolTime(LocalTime.now().hour)
    val morningDone = state.morningDate == today
    val workoutToday = if (state.workoutDate == today) state.workoutToday else 0
    val emergencyUsed = state.emergencyDate == today
    var workoutInput by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = tr(lang, "سلام، $name", "Hi, $name"),
            style = MaterialTheme.typography.headlineSmall,
            color = Accent
        )
        Spacer(Modifier.height(12.dp))

        HomeCard {
            Text(tr(lang, "امروز", "Today"), style = MaterialTheme.typography.titleMedium, color = TextColor)
            Spacer(Modifier.height(8.dp))
            if (!morningDone) {
                Text(
                    tr(lang, "امروز چه برنامه‌ای داری؟", "What's your plan today?"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedColor
                )
                Spacer(Modifier.height(8.dp))
                Row {
                    Button(onClick = { scope.launch { store.setMorning(today, "full") } }) {
                        Text(tr(lang, "ورزش کامل", "Full workout"))
                    }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { scope.launch { store.setMorning(today, "rest") } }) {
                        Text(tr(lang, "استراحت", "Rest"))
                    }
                }
            } else {
                Text(planText(lang, state.morningChoice), style = MaterialTheme.typography.bodyMedium, color = MutedColor)
            }
        }
        Spacer(Modifier.height(12.dp))

        HomeCard {
            Text(tr(lang, "بانک استراحت", "Rest bank"), style = MaterialTheme.typography.titleMedium, color = TextColor)
            Spacer(Modifier.height(6.dp))
            Text(
                tr(lang, "${state.bankMinutes} از ${RewardRules.BANK_CAP_MINUTES} دقیقه",
                    "${state.bankMinutes} of ${RewardRules.BANK_CAP_MINUTES} min"),
                style = MaterialTheme.typography.bodyMedium, color = MutedColor
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { scope.launch { store.addBank(RewardRules.randomBreakMinutes()) } }) {
                Text(tr(lang, "ثبت یک استراحت رندوم", "Add a random break"))
            }
        }
        Spacer(Modifier.height(12.dp))

        HomeCard {
            Text(tr(lang, "ثبت تمرین", "Log workout"), style = MaterialTheme.typography.titleMedium, color = TextColor)
            Spacer(Modifier.height(6.dp))
            Text(
                tr(lang, "امروز: $workoutToday دقیقه تمرین", "Today: $workoutToday min"),
                style = MaterialTheme.typography.bodyMedium, color = MutedColor
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = workoutInput,
                onValueChange = { workoutInput = it.filter { c -> c.isDigit() } },
                label = { Text(tr(lang, "دقیقه‌ی تمرین", "Minutes")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            val minutes = workoutInput.toIntOrNull() ?: 0
            Button(
                enabled = minutes > 0,
                onClick = {
                    val m = minutes
                    workoutInput = ""
                    scope.launch { store.logWorkout(today, m) }
                }
            ) {
                Text(tr(lang, "ثبت", "Save"))
            }
        }
        Spacer(Modifier.height(12.dp))

        HomeCard {
            Text(tr(lang, "سرگرمی", "Leisure"), style = MaterialTheme.typography.titleMedium, color = TextColor)
            Spacer(Modifier.height(6.dp))
            Text(
                tr(lang, "باقی‌مانده: ${state.leisureLeft} دقیقه", "Left: ${state.leisureLeft} min"),
                style = MaterialTheme.typography.bodyMedium, color = MutedColor
            )
            Spacer(Modifier.height(8.dp))
            Button(
                enabled = state.bankMinutes > 0,
                onClick = { scope.launch { store.moveBankToLeisure(state.bankMinutes) } }
            ) {
                Text(tr(lang, "انتقال بانک به سرگرمی", "Move bank to leisure"))
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                enabled = !emergencyUsed,
                onClick = { scope.launch { store.useEmergency(today) } }
            ) {
                Text(
                    if (emergencyUsed) tr(lang, "دکمه‌ی اضطراری امروز استفاده شده", "Emergency used today")
                    else tr(lang, "دکمه‌ی اضطراری (۳۰ دقیقه، یک بار در روز)", "Emergency (30 min, once a day)")
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        HomeCard {
            Text(tr(lang, "مدرسه", "School"), style = MaterialTheme.typography.titleMedium, color = TextColor)
            Spacer(Modifier.height(6.dp))
            Text(
                if (inSchool) tr(lang, "ساعت مدرسه است؛ سرگرمی قفل است.", "School hours: leisure is locked.")
                else tr(lang, "خارج از ساعت مدرسه.", "Outside school hours."),
                style = MaterialTheme.typography.bodyMedium, color = MutedColor
            )
        }
        Spacer(Modifier.height(12.dp))

        Text(
            tr(lang,
                "قفل واقعی برنامه‌ها و آلارم هنوز ساخته نشده‌اند. این صفحه فعلاً بانک و وضعیت را نشان می‌دهد.",
                "Real app locking and alarms are not built yet. This screen shows bank and status for now."),
            style = MaterialTheme.typography.bodySmall,
            color = MutedColor
        )
        Spacer(Modifier.height(16.dp))

        OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
            Text(tr(lang, "ویرایش پروفایل", "Edit profile"))
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onToggleLanguage, modifier = Modifier.fillMaxWidth()) {
            Text(tr(lang, "Switch to English", "تغییر به فارسی"))
        }
    }
}

@Composable
private fun HomeCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor)
    ) {
        Column(Modifier.padding(16.dp)) {
            content()
        }
    }
}

private fun planText(lang: String, choice: String): String = when (choice) {
    "full" -> tr(
        lang,
        "برنامه‌ی کامل: ۳۰ دقیقه ورزش و ۳۰ دقیقه استراحت، و بعد از مدرسه ۳ ساعت درس با استراحت‌های ۳۰ دقیقه‌ای.",
        "Full plan: 30 min workout, 30 min rest, then 3 hours of study with 30 min breaks after school."
    )
    "rest" -> tr(
        lang,
        "امروز استراحت فعال: ۳۰ دقیقه حرکت سبک و بقیه‌ی روز آزاد.",
        "Active rest: 30 min light movement, rest of the day free."
    )
    else -> ""
}
