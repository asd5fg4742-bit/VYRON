package ir.vyron.app.data

import android.content.Context
import androidx.datastore.core.IOException
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import ir.vyron.app.domain.RewardRules
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.dayDataStore by preferencesDataStore(name = "vyron_day")

data class DayState(
    val bankMinutes: Int = 0,
    val leisureLeft: Int = 0,
    val emergencyDate: String = "",
    val morningDate: String = "",
    val morningChoice: String = "",
    val workoutDate: String = "",
    val workoutToday: Int = 0
)

class DayStore(private val context: Context) {

    private object K {
        val BANK = intPreferencesKey("bank")
        val LEISURE = intPreferencesKey("leisure")
        val EMERGENCY = stringPreferencesKey("emergency_date")
        val MORNING_DATE = stringPreferencesKey("morning_date")
        val MORNING_CHOICE = stringPreferencesKey("morning_choice")
        val WORKOUT_DATE = stringPreferencesKey("workout_date")
        val WORKOUT_TODAY = intPreferencesKey("workout_today")
    }

    val state: Flow<DayState> = context.dayDataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { p ->
            DayState(
                bankMinutes = p[K.BANK] ?: 0,
                leisureLeft = p[K.LEISURE] ?: 0,
                emergencyDate = p[K.EMERGENCY] ?: "",
                morningDate = p[K.MORNING_DATE] ?: "",
                morningChoice = p[K.MORNING_CHOICE] ?: "",
                workoutDate = p[K.WORKOUT_DATE] ?: "",
                workoutToday = p[K.WORKOUT_TODAY] ?: 0
            )
        }

    suspend fun setMorning(today: String, choice: String) {
        context.dayDataStore.edit {
            it[K.MORNING_DATE] = today
            it[K.MORNING_CHOICE] = choice
        }
    }

    suspend fun addBank(minutes: Int) {
        context.dayDataStore.edit {
            it[K.BANK] = RewardRules.addToBank(it[K.BANK] ?: 0, minutes)
        }
    }

    suspend fun moveBankToLeisure(minutes: Int) {
        context.dayDataStore.edit {
            val bank = it[K.BANK] ?: 0
            val move = minOf(bank, minutes)
            it[K.BANK] = bank - move
            it[K.LEISURE] = (it[K.LEISURE] ?: 0) + move
        }
    }

    suspend fun useEmergency(today: String) {
        context.dayDataStore.edit {
            if (RewardRules.canUseEmergency(it[K.EMERGENCY] ?: "", today)) {
                it[K.EMERGENCY] = today
                it[K.LEISURE] = (it[K.LEISURE] ?: 0) + RewardRules.EMERGENCY_MINUTES
            }
        }
    }

    suspend fun logWorkout(today: String, minutes: Int) {
        context.dayDataStore.edit {
            val previous = if (it[K.WORKOUT_DATE] == today) (it[K.WORKOUT_TODAY] ?: 0) else 0
            it[K.WORKOUT_DATE] = today
            it[K.WORKOUT_TODAY] = previous + minutes
            it[K.LEISURE] = (it[K.LEISURE] ?: 0) + RewardRules.leisureFromWorkout(minutes)
        }
    }
}
