package ir.vyron.app.domain

import kotlin.math.floor

/** قوانین بانک استراحت، دکمه‌ی اضطراری و تبدیل تمرین به سرگرمی. */
object RewardRules {
    const val BANK_CAP_MINUTES = 120
    const val EMERGENCY_MINUTES = 30
    /** هر این‌قدر دقیقه تمرین، یک دقیقه سرگرمی. (۱۰۰ دقیقه ورزش ≈ ۹۰ دقیقه بازی) */
    const val WORKOUT_PER_LEISURE = 1.11
    val RANDOM_BREAK_OPTIONS = listOf(5, 10, 50)

    fun randomBreakMinutes(): Int = RANDOM_BREAK_OPTIONS.random()

    fun addToBank(bank: Int, add: Int): Int = (bank + add).coerceAtMost(BANK_CAP_MINUTES)

    fun leisureFromWorkout(workoutMinutes: Int): Int =
        floor(workoutMinutes / WORKOUT_PER_LEISURE).toInt()

    /** دکمه‌ی اضطراری فقط یک‌بار در روز. */
    fun canUseEmergency(lastUsedDate: String, today: String): Boolean = lastUsedDate != today

    /** ساعت مدرسه: ۸ تا ۱۴ */
    fun isSchoolTime(hour: Int): Boolean = hour in 8 until 14
}
