package ir.vyron.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import ir.vyron.app.data.DayStore
import ir.vyron.app.data.Profile
import ir.vyron.app.data.ProfileStore
import kotlinx.coroutines.launch

@Composable
fun VyronApp() {
    val context = LocalContext.current.applicationContext
    val profileStore = remember(context) { ProfileStore(context) }
    val dayStore = remember(context) { DayStore(context) }
    val profile by profileStore.profile.collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = VyronColors) {
        Surface(Modifier.fillMaxSize(), color = Background) {
            val p: Profile? = profile
            val lang = p?.language ?: ""
            val dir = if (lang == "en") LayoutDirection.Ltr else LayoutDirection.Rtl

            CompositionLocalProvider(LocalLayoutDirection provides dir) {
                when {
                    p == null -> Box(Modifier.fillMaxSize())

                    lang.isEmpty() -> LanguageScreen { code ->
                        scope.launch { profileStore.saveLanguage(code) }
                    }

                    p.name.isBlank() || editing -> ProfileScreen(
                        lang = lang,
                        initial = p,
                        onSave = { name, goal ->
                            scope.launch { profileStore.saveProfile(name, goal) }
                            editing = false
                        },
                        onCancel = if (editing) ({ editing = false }) else null
                    )

                    else -> HomeScreen(
                        lang = lang,
                        name = p.name,
                        store = dayStore,
                        onEdit = { editing = true },
                        onToggleLanguage = {
                            scope.launch {
                                profileStore.saveLanguage(if (lang == "fa") "en" else "fa")
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun LanguageScreen(onPick: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("VYRON", style = MaterialTheme.typography.displaySmall, color = Accent)
        Spacer(Modifier.height(8.dp))
        Text("ورزش کن، آزاد شو", style = MaterialTheme.typography.bodyLarge, color = MutedColor)
        Spacer(Modifier.height(40.dp))
        Text(
            "زبان را انتخاب کن / Choose your language",
            style = MaterialTheme.typography.titleMedium,
            color = TextColor
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onPick("fa") }, modifier = Modifier.fillMaxWidth()) { Text("فارسی") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { onPick("en") }, modifier = Modifier.fillMaxWidth()) { Text("English") }
    }
}

@Composable
private fun ProfileScreen(
    lang: String,
    initial: Profile,
    onSave: (String, String) -> Unit,
    onCancel: (() -> Unit)?
) {
    var name by remember { mutableStateOf(initial.name) }
    var goal by remember { mutableStateOf(initial.goal) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text(
            tr(lang, "پروفایل خود را بساز", "Create your profile"),
            style = MaterialTheme.typography.headlineSmall,
            color = Accent
        )
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(tr(lang, "نام", "Name")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = goal,
            onValueChange = { goal = it },
            label = { Text(tr(lang, "هدف ورزشی (اختیاری)", "Fitness goal (optional)")) },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { onSave(name.trim(), goal.trim()) },
            enabled = name.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(tr(lang, "ذخیره", "Save"))
        }
        if (onCancel != null) {
            TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
                Text(tr(lang, "انصراف", "Cancel"))
            }
        }
    }
}
